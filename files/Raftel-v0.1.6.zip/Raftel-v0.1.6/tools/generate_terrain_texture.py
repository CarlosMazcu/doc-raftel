from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# Cargar la imagen heightmap
heightmap_image = Image.open('../assets/heightmap/galicia.png').convert('L')
heightmap = np.array(heightmap_image)

# Normalizar el array heightmap a valores flotantes entre 0 y 1
heightmap_normalized = heightmap / 255.0


cmap = LinearSegmentedColormap.from_list(
    "TropicalCmap",
    [
        (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#1A75BB"),    # Agua superficial
        (0.1, "#E4D5A3"),     # Playa
        (0.15, "#D6C58A"),    # Arena tierra
        (0.2, "#9CB65A"),     # Vegetación costera
        (0.3, "#5E9732"),     # Vegetación tropical baja
        (0.4, "#3F7521"),     # Vegetación tropical media
        (0.5, "#2E5C1A"),     # Selva baja
        (0.6, "#1F4213"),     # Selva densa
        (0.7, "#50624A"),     # Colinas con vegetación
        (0.8, "#6B7866"),     # Colinas rocosas
        (0.9, "#878C7E"),     # Montañas bajas
        (1.0, "#A4A296")      # Picos montañosos
    ]
)

# Aplicar el mapa de colores a la imagen
fig, ax = plt.subplots()
ax.imshow(heightmap_normalized, cmap=cmap, interpolation='nearest')
plt.axis('off')  # Desactivar los ejes
plt.subplots_adjust(left=0, right=1, top=1, bottom=0)  # Ajustar el margen para maximizar la imagen en el lienzo

# Verifica la ruta de guardado
output_path = '../assets/textures/textura_terreno1.png'
try:
    plt.savefig(output_path, bbox_inches='tight', pad_inches=0)
except Exception as e:
    print(f"Error al guardar la imagen: {e}")

plt.show()

'''
"CustomCmap",
    [
       (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#D1B36C"),    # Agua menos profunda - última zona acuática
        (0.1, "#D1B36C"),     # Inicio de tierra/arena costera
        (0.15, "#B39B65"),    # Arena/tierra costera
        (0.25, "#8E7F50"),    # Tierra baja/base del acantilado
        (0.35, "#6E6A53"),    # Inicio de roca del acantilado
        (0.45, "#5D5D54"),    # Roca principal del acantilado
        (0.6, "#7A7A74"),     # Roca expuesta/zona media del acantilado
        (0.75, "#9A9A94"),    # Roca superior del acantilado
        (0.85, "#BAB6A7"),    # Cima del acantilado
        (0.95, "#D5D1C2"),    # Zonas más altas
        (1.0, "#E9E6DA")      # Picos rocosos más altos
    ]

    "MontañanevadaCmap",
    [
        (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#1A75BB"),    # Agua superficial
        (0.1, "#3A623F"),     # Vegetación baja/bosque
        (0.2, "#5A7E50"),     # Bosque denso
        (0.3, "#76876A"),     # Límite del bosque
        (0.4, "#938B74"),     # Zona de transición
        (0.5, "#A99D88"),     # Roca baja
        (0.6, "#BEB8AA"),     # Roca expuesta
        (0.7, "#D1CDC6"),     # Zona de transición a nieve
        (0.8, "#E3E2DF"),     # Nieve parcial
        (0.9, "#F0F0F0"),     # Nieve abundante
        (1.0, "#FFFFFF")      # Picos nevados
    ]

    "DesiertoCmap",
    [
        (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#1A75BB"),    # Agua superficial
        (0.1, "#E7C99F"),     # Arena húmeda/orilla
        (0.2, "#E6C188"),     # Arena dorada
        (0.3, "#D9B678"),     # Dunas bajas
        (0.4, "#CCAA6A"),     # Dunas medias
        (0.5, "#BF9958"),     # Dunas altas
        (0.6, "#AD8242"),     # Terreno rocoso bajo
        (0.7, "#96703C"),     # Terreno rocoso
        (0.8, "#7C5A32"),     # Rocas altas
        (0.9, "#634628"),     # Mesetas
        (1.0, "#4A321E")      # Picos rocosos
    ]
    "TropicalCmap",
    [
        (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#1A75BB"),    # Agua superficial
        (0.1, "#E4D5A3"),     # Playa
        (0.15, "#D6C58A"),    # Arena tierra
        (0.2, "#9CB65A"),     # Vegetación costera
        (0.3, "#5E9732"),     # Vegetación tropical baja
        (0.4, "#3F7521"),     # Vegetación tropical media
        (0.5, "#2E5C1A"),     # Selva baja
        (0.6, "#1F4213"),     # Selva densa
        (0.7, "#50624A"),     # Colinas con vegetación
        (0.8, "#6B7866"),     # Colinas rocosas
        (0.9, "#878C7E"),     # Montañas bajas
        (1.0, "#A4A296")      # Picos montañosos
    ]

    "VolcánicoCmap",
    [
        (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#1A75BB"),    # Agua superficial
        (0.1, "#2E2E2E"),     # Roca volcánica negra
        (0.2, "#3A3A3A"),     # Roca volcánica
        (0.3, "#474747"),     # Rocas bajas
        (0.4, "#5A5A5A"),     # Pendiente volcánica
        (0.5, "#707070"),     # Roca volcánica media
        (0.6, "#8A6F55"),     # Transición a tierra quemada
        (0.7, "#A85A3A"),     # Tierra quemada
        (0.8, "#C14B28"),     # Zona caliente
        (0.9, "#E33E14"),     # Magma superficial
        (1.0, "#FF3300")      # Cráter/lava
    ]

    "TundraCmap",
    [
        (0.0, "#0D4F8B"),     # Agua profunda (azul oscuro)
        (0.05, "#1A75BB"),    # Agua superficial
        (0.1, "#C9D2D0"),     # Hielo/nieve derretida
        (0.2, "#B8C3C1"),     # Transición hielo-tierra
        (0.3, "#9BA7A0"),     # Tundra rocosa
        (0.4, "#7C8980"),     # Tundra con musgo
        (0.5, "#5E6C62"),     # Vegetación baja de tundra
        (0.6, "#485548"),     # Vegetación resistente
        (0.7, "#38473D"),     # Colinas de tundra
        (0.8, "#2C3C34"),     # Montañas bajas
        (0.9, "#212F29"),     # Montañas medias
        (1.0, "#19231F")      # Picos montañosos oscuros
    ]



'''
