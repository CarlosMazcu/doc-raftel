#include "raftel/window.hpp"
#include "raftel/shader.hpp"
#include "raftel/ecs.hpp"
#include "raftel/camera.hpp"
#include "raftel/imguiRenderer.hpp"
#include "raftel/systems.hpp"
#include "raftel/input.hpp"
#include "raftel/imguiWindows.hpp"
#include <fstream>
#include <string>




int main(void)
{
	// create window system and wyndow
    auto windowSystemOpt = Raftel::WindowSystem::make();
    auto windowOpt = Raftel::Window::make("WindowTest", *windowSystemOpt);
	if (!windowOpt) {
		std::cerr << "Can't create window\n";
		return -1;
	}

	// make window context
	windowOpt->MakeContextCurrent();

	//Create camera
	Raftel::Camera cam(windowOpt.get());
	cam.SetPosition(glm::vec3(36.0f, -163.0f, -270.0f));
	cam.SetRotation(glm::vec3(0.4f, 80.8f, 0.0f));

	// to create and show entities you need create entity system (ecs)
	auto ecs = std::make_unique<Raftel::EntityManager>();

	// we will create a entity terrain 
	// create entity

	// create texture and mesh
	auto cube_t = Raftel::Texture::loadTexture("../assets/textures/textura_terreno1.png");
	auto terrainMesh = Raftel::MeshFactory::createTerrain("../assets/heightmap/galicia.png", 1.0f, 200.0f, true);
	terrainMesh->GetMaterialByIndex(0)->setAlbedo(cube_t);
	terrainMesh->setupMesh();

	auto terrain = ecs->CreateEntity();
	// add components to the entity
	terrain.addMeshComp(terrainMesh);
	terrain.addRenderComp(true);
	terrain.addTransformComp(Raftel::TransformComponent{
		glm::vec3(0.0f, -200.0f, -400.0f),
		glm::vec3(0.0f),
		glm::vec3(1.0f)
		});

	Raftel::Engine::Instance().has_ambient_light = true;
	Raftel::Engine::Instance().ambient_light = glm::vec3(0.18f, 0.09f, 0.31f);
	//add some light
	auto spotLightEntity = ecs->CreateEntity();
    spotLightEntity.addLightComp(Raftel::LightComponent(
        Raftel::LightComponent::LightType::DIRECTIONAL,
        glm::vec3(0.55f, 0.58f, 0.6f),
        0.3f, 0.1f, 20.0f, 30.0f,
        windowOpt->getScreenSize()));
    //spotLightEntity.addMeshComp(Raftel::MeshFactory::createSphere(2.0f, 20));
    //spotLightEntity.addRenderComp(true);
    spotLightEntity.addTransformComp({ glm::vec3(-230.0f, -150.0f, -240.0f), glm::vec3(90.0f, 0.0f, -180.0f), glm::vec3(10.0f) });

	std::shared_ptr<Raftel::Texture> skyboxtexture = Raftel::Texture::loadCubemap({ "../assets/textures/skybox/sky_night/px.png",
																				   "../assets/textures/skybox/sky_night/nx.png",
																				   "../assets/textures/skybox/sky_night/py.png",
																				   "../assets/textures/skybox/sky_night/ny.png",
																				   "../assets/textures/skybox/sky_night/pz.png",
																				   "../assets/textures/skybox/sky_night/nz.png" });

	auto lighthousemesh = Raftel::Mesh::Create("../assets/obj/lighthouse.obj", false);
	auto lighthousetext = Raftel::Texture::loadTexture("../assets/textures/lighthouse_baked.png");
	lighthousemesh->GetMaterialByIndex(0)->setAlbedo(lighthousetext);
	lighthousemesh->setupMesh();
	auto lighthouse = ecs->CreateEntity();
	lighthouse.addRenderComp(true);
	lighthouse.addMeshComp(lighthousemesh);
	lighthouse.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-48.0f, -175.0f, -290.0f),
		glm::vec3(0.0f),
		glm::vec3(10.0f)
		});

	auto shipmesh = Raftel::Mesh::Create("../assets/obj/kennye/boat-sail-b.obj", false);
	shipmesh->setupMesh();
	auto ship = ecs->CreateEntity();
	ship.addRenderComp(true);
	ship.addMeshComp(shipmesh);
	ship.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-170.0f, -196.0f, -240.0f),
		glm::vec3(0.0f),
		glm::vec3(2.0f)
		});

	auto shipmesh1 = Raftel::Mesh::Create("../assets/obj/kennye/boat-sail-a.obj", false);
	shipmesh1->setupMesh();
	auto ship1 = ecs->CreateEntity();
	ship1.addRenderComp(true);
	ship1.addMeshComp(shipmesh1);
	ship1.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-141.0f, -196.0f, -226.0f),
		glm::vec3(0.0f, 138.0f, 0.0f),
		glm::vec3(2.0f)
		});


	auto rampmesh = Raftel::Mesh::Create("../assets/obj/kennye/ramp.obj", false);
	rampmesh->setupMesh();


	auto ramp = ecs->CreateEntity();
	ramp.addRenderComp(true);
	ramp.addMeshComp(rampmesh);
	ramp.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-75.907f, -196.699f, -262.439f),
		glm::vec3(-180.0f, -82.0f, -166.00f),
		glm::vec3(2.0f)
		});

	auto ramp2 = ecs->CreateEntity();
	ramp2.addRenderComp(true);
	ramp2.addMeshComp(rampmesh);
	ramp2.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-78.0f, -197.158f, -257.0f),
		glm::vec3(-180.0f, -82.0f, -166.00f),
		glm::vec3(2.0f)
		});
	auto ramp3 = ecs->CreateEntity();
	ramp3.addRenderComp(true);
	ramp3.addMeshComp(rampmesh);
	ramp3.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-78.0f, -197.138f, -252.0f),
		glm::vec3(-180.0f, -82.0f, -166.00f),
		glm::vec3(2.0f)
		});


	auto spotlighthouse = ecs->CreateEntity();
	spotlighthouse.addLightComp(Raftel::LightComponent(
		Raftel::LightComponent::LightType::SPOT,
		glm::vec3(1.0f, 0.75f, 0.7f),
		1.0f, 500.0f, 20.0f, 30.0f,
		windowOpt->getScreenSize()));
	//spotlighthouse.addMeshComp(Raftel::MeshFactory::createSphere(2.0f, 20));
	//spotlighthouse.addRenderComp(true);
	spotlighthouse.addTransformComp(Raftel::TransformComponent{
		glm::vec3(-48.0f, -165.0f, -290.0f),
		glm::vec3(0.0f),
		glm::vec3(1.0f)
		});
	Raftel::RenderSystem::Initialize();
	Raftel::RenderSystem::SetSkyboxTexture(skyboxtexture);

	//our engine has ImGui support, if you want to use it, only need create:
	Raftel::imguiRenderer ImguiRender(windowOpt->window_);
	//and update each frame
	//also we have a editor class that you can manage some things
	Raftel::Editor editor;
	float sunset = -180.0f;
	float spotlightpitch = 0.0f;
	static double lastTime = 0.0;

	while (!windowOpt->ShouldClose())
	{
		double currentTime = glfwGetTime();
		double deltaTime = currentTime - lastTime;
		//update input
		windowOpt->input->updateKeys();
		windowOpt->clear();

		//preset camera controls
		cam.PresetCamera(windowOpt.get());
		//update camera
		cam.Update(windowOpt);

		spotLightEntity.setRotation(glm::vec3(90.0f, 0.0f, sunset));
		spotlighthouse.setRotation(glm::vec3(0.0f, spotlightpitch, 0.0f));

		//render system -> render the entities that you create in the ecs
		Raftel::RenderSystem::UpdateRenderSystem(*ecs, cam, windowOpt->getScreenSize(), true);
		//ImguiRender.newFrame();
		////ImGui functions between this one, like:
		//editor.Show(cam, *ecs, windowOpt.get());
		//ImguiRender.endFrame();

		windowOpt->swapBuffers();
		sunset += 30.0f * deltaTime;
		spotlightpitch += 10.0f * deltaTime;
		if (sunset >= 180.0f)
		{
			sunset = -180.0f;
		}
		if (spotlightpitch >= 360.0f)
		{
			spotlightpitch = 0.0f;
		}
		lastTime = currentTime;
	}

	Raftel::RenderSystem::Shutdown();
    return 0;
}