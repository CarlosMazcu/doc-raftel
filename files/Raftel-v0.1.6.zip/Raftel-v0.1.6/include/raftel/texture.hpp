/**
 * @file texture.hpp
 * @brief Contains the definitions for the `TextureImage` and `Texture` classes.
 * @date 2025-03-10
 * @authors Carlos Mazcu��n Blanes, Marc Folgado Balb�s
 *
 * @copyright All rights reserved.
 *
 * The `TextureImage` class holds raw image data used to create textures in OpenGL.
 * The `Texture` class wraps the OpenGL texture functionality, allowing loading, binding,
 * and managing of textures, as well as error handling for texture operations.
 *
 * The `TextureImage` class is responsible for storing the texture's image data, width, height,
 * and number of channels, while the `Texture` class encapsulates the OpenGL texture object
 * and provides methods for handling textures in the graphics pipeline.
 */

#ifndef __TEXTURE_H__
#define __TEXTURE_H__ 1

#pragma once

#include <GL/glew.h>
#include <iostream>
#include <raftel/global_macros.hpp>
#include <vector>

namespace Raftel {

	class ShaderProgram;
	/**
	 * @class TextureImage
	 * @brief Represents an image containing texture data.
	 *
	 * The `TextureImage` class is used to store the raw image data, including width, height,
	 * and the number of channels. This class is typically used as an intermediate data structure
	 * before creating an OpenGL texture.
	 */
	class TextureImage {
	public:
		unsigned char* data; ///< Pointer to the raw image data.
		int width;            ///< Width of the image.
		int height;           ///< Height of the image.
		int n_channel;        ///< Number of channels in the image (e.g., 3 for RGB, 4 for RGBA).
		
		/**
		 * @brief Construct a `TextureImage` object.
		 *
		 * @param data The raw image data.
		 * @param width The width of the image.
		 * @param height The height of the image.
		 * @param n_channel The number of channels in the image (e.g., 3 for RGB, 4 for RGBA).
		 */
		TextureImage(unsigned char* data, int width, int height, int n_channel);
		
		 /**
         * @brief Destructor that frees the image data.
         */
		~TextureImage();

		/**
		 * @brief Move constructor.
		 *
		 * Transfers ownership of the image data from another `TextureImage`.
		 * @param other The `TextureImage` to move from.
		 */
		MOVABLE_BUT_NOT_COPYABLE(TextureImage)

	private:

	};
	/**
	* @enum TextureType
	* @brief Specifies the type of texture.
	*/
	enum class TextureType {
		TEXTURE_2D,  /**< Standard 2D texture. */
		CUBEMAP      /**< Cube map texture used for skyboxes and reflections. */
	};
	/**
	* @class Texture
	* @brief Represents an OpenGL texture object.
	*
	* The `Texture` class wraps the OpenGL texture object, providing functions to load, bind,
	* and manage textures. It also includes functionality for error handling related to texture loading.
	*/

	class Texture {
	public:
		GLuint id;///< OpenGL texture ID.
		TextureType type;///< Specifies the type of texture (2D or Cubemap)

		/**
		* @brief Default constructor that initializes the texture ID to 0.
		*/
		Texture() : id(0), type(TextureType::TEXTURE_2D){}
		
		/**
		* @brief Constructs a cubemap texture from six image files.
		*
		* This constructor loads a set of six images and creates a cubemap texture
		* used for skyboxes or environment mapping.
		*
		* The images must be provided in the following order:
		* - Right (+X)
		* - Left (-X)
		*
		* - Top (+Y)
		* - Bottom (-Y)
		* 
		* - Front (+Z)
		* - Back (-Z)
		*
		* @param faces A vector containing the file paths of the six images.
		*/
		Texture(const std::vector<std::string>& faces);

		/**
		 * @brief Constructor that creates an OpenGL texture from a `TextureImage`.
		 *
		 * @param image The `TextureImage` that contains the image data to create the texture.
		 */
		Texture(TextureImage image);

		/**
		* @brief Destructor that deletes the OpenGL texture.
		*/
		~Texture();

		/**
		 * @brief Loads a texture from a file and creates an OpenGL texture object.
		 *
		 * This function uses the `stb_image` library to load an image from disk and then creates
		 * an OpenGL texture object with the image data.
		 *
		 * @param texturePath The file path to the texture image.
		 * @return A shared pointer to the loaded texture.
		 */
		static std::shared_ptr<Texture> loadTexture(const std::string& texturePath);

		/**
		* @brief Loads a cubemap texture from six image files.
		*
		* This function creates an OpenGL cubemap texture using the six provided
		* images representing the faces of a cube. The order of the images must be:
		* - Right
		* - Left
		* - Top
		* - Bottom
		* - Front
		* - Back
		*
		* @param faces A vector containing the file paths of the six images.
		* @return std::shared_ptr<Texture> A shared pointer to the loaded cubemap texture.
		*/
		static std::shared_ptr<Texture> loadCubemap(const std::vector<std::string>& faces);

		/**
		* @brief Binds the texture to a texture unit.
		*
		* This function binds the texture to the specified texture unit and sets the corresponding
		* shader sampler to the texture unit.
		*
		* @param unit The texture unit to bind the texture to (e.g., 0, 1, etc.).
		* @param sample The name of the sampler uniform in the shader.
		* @param shader_program The shader program to which the texture is bound.
		*/
		void bind(int unit) const;

		/**
		 * @brief Gets the last error message generated by texture operations.
		 *
		 * @return A string containing the last error message.
		 */
		const std::string& getLastError() const { return lastError; }

		/**
		 * @brief Move constructor.
		 *
		 * Transfers ownership of the OpenGL texture ID from another `Texture`.
		 * @param other The `Texture` to move from.
		 */
		MOVABLE_BUT_NOT_COPYABLE(Texture)
		
		/**
		* @brief Gets the OpenGL texture ID.
		*
		* @return GLuint The OpenGL texture ID.
		*/
		GLuint getID() const { return id; }

	private:
		/**
		* @brief Loads texture data from a file.
		*
		* This function loads image data from a file using `stb_image` and returns it as a
		* `TextureImage` object.
		*
		* @param path The file path to the texture.
		* @return A `TextureImage` containing the loaded image data.
		*/
		static TextureImage LoadTexture(const char* path);

		/**
	   * @brief Sets an error message related to texture operations.
	   *
	   * This function sets the `lastError` variable with the provided error message and
	   * prints it to the console.
	   *
	   * @param errorMessage The error message to store.
	   * @param file The file where the error occurred.
	   * @param line The line number where the error occurred.
	   */
		void setError(const std::string& errorMessage, const char* file, int line);
		std::string lastError;///< The last error message related to texture operations.
	};
}
#endif