#ifndef __RAYCASTS_H__
#define __RAYCASTS_H__ 1

#pragma once

#include <glm/glm.hpp>
#include <utility>

namespace Raftel {
    class EntityManager;
    /**
     * @struct Ray
     * @brief Represents a ray in 3D space with an origin point and direction vector.
     *
     * A ray is defined by its origin point and a normalized direction vector.
     * It is used for raycasting operations like picking and collision detection.
     */
    struct Ray {
        glm::vec3 origin;    /**< Origin point of the ray in world space. */
        glm::vec3 direction; /**< Normalized direction vector of the ray. */
    };

    /**
     * @brief Generates a ray from mouse position in screen space.
     * @param mousePos The mouse position in screen coordinates (pixels).
     * @param projection The projection matrix used by the camera.
     * @param view The view matrix used by the camera.
     * @param viewportSize The size of the viewport in pixels.
     * @return A ray originating from the camera position and passing through the mouse position.
     *
     * This function transforms a 2D mouse position into a 3D ray in world space.
     * The ray starts at the camera position and passes through the point on the near plane
     * corresponding to the mouse position.
     */
    Ray GenerateRay(const glm::vec2& mousePos, const glm::mat4& projection, const glm::mat4& view, glm::ivec2 viewportSize);

    /**
    * @brief Tests if a ray intersects an oriented bounding box (OBB).
    * @param ray The ray to test for intersection.
    * @param aabbMin The minimum point of the axis-aligned bounding box in local space.
    * @param aabbMax The maximum point of the axis-aligned bounding box in local space.
    * @param modelMatrix The model matrix that transforms the AABB to an OBB in world space.
    * @param intersectionDistance Output parameter that receives the distance from ray origin to intersection point.
    * @return True if the ray intersects the OBB, false otherwise.
    *
    * This function tests if a ray intersects an oriented bounding box (OBB).
    * The OBB is defined by an axis-aligned bounding box (AABB) in local space
    * and a model matrix that transforms it to world space.
    * If an intersection is found, the distance along the ray to the intersection point is stored
    * in the intersectionDistance parameter.
    */
    bool RayIntersectsOBB(const Ray& ray, const glm::vec3& aabbMin, const glm::vec3& aabbMax, const glm::mat4& modelMatrix, float& intersectionDistance);

    /**
    * @brief Tests if a ray intersects any entity managed by the EntityManager.
    * @param ray The ray to test for intersection.
    * @param ecs The EntityManager containing the entities to test against.
    * @return A pair containing a boolean indicating if an intersection occurred, and the ID of the intersected entity (or 0 if no intersection).
    *
    * This function tests if a ray intersects any entity managed by the EntityManager.
    * It returns a pair where the first element is a boolean indicating if an intersection occurred,
    * and the second element is the ID of the intersected entity. If multiple entities are intersected,
    * the closest one to the ray origin is returned. If no intersection occurred, the second element is 0.
    */
    std::pair<bool,size_t> IntersectionWithEntities(const Ray& ray, const EntityManager& ecs);
} // namespace Raftel

#endif