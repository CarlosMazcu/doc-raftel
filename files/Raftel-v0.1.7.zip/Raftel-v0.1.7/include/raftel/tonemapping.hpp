#ifndef __TONEMAPPING_HPP__
#define __TONEMAPPING_HPP__ 1

#pragma once
#include <raftel/shader.hpp>

namespace Raftel {

    /**
     * @struct SceneMetrics
     * @brief Contains metrics describing the luminance and color properties of a rendered scene.
     *
     * This structure holds various metrics calculated from analyzing an HDR scene,
     * which are used for adaptive tonemapping and other post-processing adjustments.
     */
    struct SceneMetrics {
        float avgLuminance;    /**< Average luminance of the scene. */
        float maxLuminance;    /**< Maximum luminance value in the scene. */
        float minLuminance;    /**< Minimum luminance value in the scene. */
        float dynamicRange;    /**< Ratio between max and min luminance (contrast). */
        float colorfulness;    /**< Measure of overall color saturation. */
    };

#pragma region SceneAnalyzer
    /**
    * @class SceneAnalyzer
    * @brief Analyzes HDR scenes to extract luminance and color metrics.
    *
    * This class performs real-time analysis of HDR rendered content to extract
    * metrics like average luminance, dynamic range, and colorfulness.
    * These metrics are used by the AdaptiveTonemapper to adjust rendering parameters.
    */
    class SceneAnalyzer {
    public:
        /**
        * @brief Constructor that initializes the scene analyzer with specified dimensions.
        * @param width Width of the viewport in pixels.
        * @param height Height of the viewport in pixels.
        */
        SceneAnalyzer(int width, int height);

        /**
        * @brief Destructor that releases all resources used by the analyzer.
        */
        ~SceneAnalyzer();

        /**
         * @brief Macro that makes the class movable but not copyable.
         *
         * Implements move constructors and operators while disabling copy constructors and operators.
         */
        MOVABLE_BUT_NOT_COPYABLE(SceneAnalyzer)

        /**
        * @brief Analyzes an HDR texture and calculates scene metrics.
        * @param inputTexture OpenGL texture ID of the HDR texture to analyze.
        * @return SceneMetrics structure containing the analysis results.
        *
        * This method samples the input HDR texture and performs various calculations
        * to extract luminance and color metrics used for adaptive tonemapping.
        */
        SceneMetrics analyzeScene(GLuint inputTexture);

        /**
         * @brief Resizes the internal buffers to match a new viewport size.
         * @param width New width of the viewport in pixels.
         * @param height New height of the viewport in pixels.
         */
        void resize(int width, int height);

    private:
        /**
        * @brief Initializes internal resources needed for scene analysis.
        *
        * Sets up framebuffers, textures and other OpenGL resources.
        */
        void initializeResources();

        /**
        * @brief Initializes internal shader needed for scene analysis.
        *
        * Sets up shaders resources.
        */
        void initializeShader();
        /**
        * @brief Cleans up internal resources when the analyzer is destroyed.
        */
        void cleanup();

        /**
        * @brief Renders a screen-filling quad for processing the HDR texture.
        */
        void renderQuad();



        int m_width, m_height; /**< Dimensions of the viewport in pixels. */

        GLuint m_analysisFBO; /**< OpenGL framebuffer object used for scene analysis. */
        GLuint m_analysisTexture; /**< OpenGL texture used to store analysis results. */

        Raftel::ShaderProgram m_analysisShader; /**< Shader program used for analyzing the scene. */

        SceneMetrics m_currentMetrics; /**< Current metrics from the latest scene analysis. */

        GLuint m_quadVAO; /**< Vertex Array Object for the screen-filling quad. */
        GLuint m_quadVBO; /**< Vertex Buffer Object for the screen-filling quad vertices. */
    };
#pragma endregion

#pragma region AdaptiveTonemapper
    
    /**
     * @class AdaptiveTonemapper
     * @brief Dynamically adjusts tonemapping parameters based on scene content.
     *
     * This class uses the metrics from the SceneAnalyzer to automatically adapt
     * exposure, contrast, and saturation parameters for optimal visual appearance
     * across a wide range of lighting scenarios.
     */
    class AdaptiveTonemapper {
    public:
         /**
         * @brief Constructor that initializes the adaptive tonemapper with default settings.
         */
        AdaptiveTonemapper();

        /**
         * @brief Destructor that releases all resources used by the tonemapper.
         */
        ~AdaptiveTonemapper();

        /**
         * @brief Macro that makes the class movable but not copyable.
         *
         * Implements move constructors and operators while disabling copy constructors and operators.
         */
        MOVABLE_BUT_NOT_COPYABLE(AdaptiveTonemapper)

        /**
        * @brief Updates internal parameters based on the given scene metrics.
        * @param metrics Scene metrics from the SceneAnalyzer.
        *
        * Recalculates and adjusts exposure, contrast, and saturation based on
        * the current scene metrics, adaptation speed, and other settings.
        */
        void update(const SceneMetrics& metrics);

        /**
         * @brief Gets the current exposure value.
         * @return The current adaptive exposure value.
         */
        float getExposure() const { return m_exposure; }

        /**
         * @brief Gets the current contrast value.
         * @return The current adaptive contrast value.
         */
        float getContrast() const { return m_contrast; }

        /**
         * @brief Gets the current saturation value.
         * @return The current adaptive saturation value.
         */
        float getSaturation() const { return m_saturation; }

        /**
          * @brief Sets the target middle gray value used for luminance adaptation.
          * @param value New middle gray target value (typically between 0.18 and 0.5).
          *
          * This value determines what luminance level is mapped to middle gray in the final image.
          */
        void setTargetMiddleGray(float value) { m_targetMiddleGray = value; }

        /**
         * @brief Gets the current target middle gray value.
         * @return The current target middle gray value.
         */
        float getTargetMiddleGray() const { return m_targetMiddleGray; }

        /**
         * @brief Sets the speed at which the tonemapper adapts to changing scenes.
         * @param value New adaptation speed (typically between 0.01 and 1.0).
         *
         * Lower values create smoother transitions but slower adaptation,
         * while higher values adapt quickly but may cause flickering.
         */
        void setAdaptationSpeed(float value) { m_adaptationSpeed = value; }

        /**
         * @brief Gets the current adaptation speed.
         * @return The current adaptation speed.
         */
        float getAdaptationSpeed() const { return m_adaptationSpeed; }

        /**
         * @brief Sets the base parameters used for a "normal" scene.
         * @param exposure Base exposure value.
         * @param contrast Base contrast value.
         * @param saturation Base saturation value.
         *
         * These parameters serve as the starting point for adaptive adjustments.
         */
        void setBaseParameters(float exposure, float contrast, float saturation);

    private:
        /**
          * @brief Calculates adaptive parameters based on the given scene metrics.
          * @param metrics Scene metrics from the SceneAnalyzer.
          *
          * Internal method that implements the adaptive algorithm to adjust
          * exposure, contrast, and saturation based on scene content.
          */
        void calculateAdaptiveParameters(const SceneMetrics& metrics);

        float m_targetMiddleGray; /**< Target value for middle gray (typically 0.18). */
        float m_adaptationSpeed; /**< Speed of adjustment to changing scenes. */

        float m_baseExposure; /**< Base exposure parameter for a "normal" scene. */
        float m_baseContrast; /**< Base contrast parameter for a "normal" scene. */
        float m_baseSaturation; /**< Base saturation parameter for a "normal" scene. */

        float m_exposure; /**< Current adaptive exposure value. */
        float m_contrast; /**< Current adaptive contrast value. */
        float m_saturation; /**< Current adaptive saturation value. */

        /**
         * @struct Limits
         * @brief Contains min/max limits for tonemapping parameters.
         */
        struct {
            float minExposure; /**< Minimum allowed exposure value. */
            float maxExposure; /**< Maximum allowed exposure value. */
            float minContrast; /**< Minimum allowed contrast value. */
            float maxContrast; /**< Maximum allowed contrast value. */
            float minSaturation; /**< Minimum allowed saturation value. */
            float maxSaturation; /**< Maximum allowed saturation value. */
        } m_limits; /**< Parameter limits to prevent extreme values. */
    };
#pragma endregion
} // Raftel

#endif // !__TONEMAPPING_HPP__
