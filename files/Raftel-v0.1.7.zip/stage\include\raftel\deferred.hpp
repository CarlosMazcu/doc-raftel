#ifndef __DEFERRED_H__
#define __DEFERRED_H__ 1

#pragma once

#include <raftel/global_macros.hpp>
#include <Raftel/shader.hpp>
#include <memory>

namespace Raftel {

    class DeferredRender
    {
     public:
         DeferredRender(int w, int h);
         ~DeferredRender();
         void StartPocess();
         void EndProcess();
         void BindTextures();
         void resize(int width, int height);
         GLuint GetFrameBuffer() const {
             return frameBuffer;
         }
         std::shared_ptr<ShaderProgram> shader;


         unsigned int gPosition, gNormal, gAlbedoSpec, gRoughMetal;
        
         NO_COPYABLE_OR_MOVABLE(DeferredRender)
     private:
         int width;
         int height;
         unsigned int frameBuffer;
         unsigned int rboDepth;
         void initialize();
         void cleanup();
    };
}

#endif