//#version 460 core
//layout (location = 0) out vec3 gPosition;
//layout (location = 1) out vec3 gNormal;
//layout (location = 2) out vec4 gAlbedoSpec;
//
//in vec2 TexCoords;
//in vec3 FragPos;
//in vec3 Normal;
//
//layout (binding = 0)uniform sampler2D texture_diffuse1;
//layout (binding = 4)uniform sampler2D texture_specular1;
//
//void main()
//{    
//    // store the fragment position vector in the first gbuffer texture
//    gPosition = FragPos;
//    // also store the per-fragment normals into the gbuffer
//    gNormal = normalize(Normal);
//    // and the diffuse per-fragment color
//    gAlbedoSpec.rgb = texture(texture_diffuse1, TexCoords).rgb;
//    // store specular intensity in gAlbedoSpec's alpha component
//    gAlbedoSpec.a = texture(texture_specular1, TexCoords).r;
//}
#version 460 core
layout (location = 0) out vec4 gPosition;
layout (location = 1) out vec4 gNormal;
layout (location = 2) out vec4 gAlbedoSpec;
layout (location = 3) out vec4 gRoughMetal;  // Rugosidad (R) y Metalicidad (G), SSS-Factor (B)

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;

// Texturas del material
layout(binding = 0) uniform sampler2D albedoTexture;
uniform int has_alb_text;

layout(binding = 1) uniform sampler2D normalTexture;
uniform int has_norm_text;

layout(binding = 2) uniform sampler2D roughnessTexture;
uniform int has_rough_text;

layout(binding = 3) uniform sampler2D metallicTexture;
uniform int has_met_text;

// Propiedades del material
uniform vec3 u_color;            // Color base del material
uniform float u_shininess;       // Tamaño del brillo especular
uniform float u_roughnessValue;  // Rugosidad del material
uniform float u_metallicValue;   // Metalicidad del material
uniform float u_fresnel;         // Factor de Fresnel
uniform float u_ssFactor;        // Factor de dispersión de la luz

// Calcular la tangente y bitangente para el mapa de normales
vec3 calculateTangent(vec3 normal) {
    vec3 tangent;
    if (abs(normal.x) > abs(normal.z)) {
        tangent = vec3(-normal.y, normal.x, 0.0);
    } else {
        tangent = vec3(0.0, -normal.z, normal.y);
    }
    return normalize(tangent);
}

// Función para calcular el mapa de normales
vec3 CalculateNormalMap(vec3 normal, vec3 tangent, vec3 bitangent, vec2 texCoord) {
    if (has_norm_text == 0) {
        return normal; // Si no hay textura de normales, usar la normal geométrica
    }

    // Obtener el valor del mapa de normales
    vec3 normalMap = texture(normalTexture, texCoord).rgb;
    normalMap = normalize(normalMap * 2.0 - 1.0); // Convertir de [0, 1] a [-1, 1]

    // Crear la matriz TBN (Tangent, Bitangent, Normal)
    mat3 TBN = mat3(tangent, bitangent, normal);
    return normalize(TBN * normalMap); // Transformar la normal al espacio del mundo
}

void main() {
    // Guardar posición del fragmento
    gPosition = vec4(FragPos, 1.0);
    
    // Calcular normal (con mapa de normales si está disponible)
    vec3 norm = normalize(Normal);
    if (has_norm_text == 1) {
        vec3 tangent = calculateTangent(norm);
        vec3 bitangent = cross(norm, tangent);
        norm = CalculateNormalMap(norm, tangent, bitangent, TexCoords);
    }
    gNormal = vec4(norm, 1.0);
    
    // Guardar color y especular/shininess
    vec3 albedo = has_alb_text == 1 ? texture(albedoTexture, TexCoords).rgb : u_color;
    float specular = u_shininess / 128.0; // Normalizar shininess al rango [0-1]
    gAlbedoSpec = vec4(albedo, specular);
    
    // Guardar rugosidad, metalicidad y factor de subsurface scattering
    float roughness = has_rough_text == 1 ? texture(roughnessTexture, TexCoords).r : u_roughnessValue;
    float metallic = has_met_text == 1 ? texture(metallicTexture, TexCoords).r : u_metallicValue;
    gRoughMetal = vec4(roughness, metallic, u_ssFactor, u_fresnel);
}