#version 460 core

struct perVertex{
    vec4 color;
};

layout (location=0) in perVertex vtx;
layout (location=0) out vec4 FragColor; 


void main() {
    FragColor = vtx.color;
}