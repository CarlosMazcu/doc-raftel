#ifndef __HDR_HPP__
#define __HDR_HPP__ 1
#pragma once
#include <GL/glew.h>
#include <memory>
#include "raftel/shader.hpp"
#include "raftel/tonemapping.hpp"

namespace Raftel {
    /**
    * @class HDRFramebuffer
    * @brief Manages a High Dynamic Range (HDR) framebuffer for advanced rendering.
    *
    * This class encapsulates the creation and management of an OpenGL framebuffer with HDR support,
    * allowing rendering of scenes with a greater luminance range than standard framebuffers.
    */
    class HDRFramebuffer {
    public:
        
        /**
        * @brief Constructor that initializes an HDR framebuffer with specified dimensions.
        * @param width Width of the framebuffer in pixels.
        * @param height Height of the framebuffer in pixels.
        */
        HDRFramebuffer(int width, int height);
        
        /**
        * @brief Destructor that releases the OpenGL resources associated with the framebuffer.
        */
        ~HDRFramebuffer();
        
        /**
        * @brief Macro that makes the class movable but not copyable.
        *
        * Implements move constructors and operators while disabling copy constructors and operators.
        */
        MOVABLE_BUT_NOT_COPYABLE(HDRFramebuffer)
        
        /**
        * @brief Resizes the framebuffer to a new size.
        * @param width New width of the framebuffer in pixels.
        * @param height New height of the framebuffer in pixels.
        */
        void resize(int width, int height);
        
        /**
        * @brief Binds this framebuffer for rendering.
        *
        * Any OpenGL rendering commands after this call will be drawn to this HDR framebuffer.
        */
        void bind();

        /**
        * @brief Unbinds this framebuffer, returning to the default framebuffer.
        */
        void unbind();

        /**
        * @brief Gets the OpenGL framebuffer object (FBO) identifier.
        * @return The OpenGL identifier of the FBO.
        */
        GLuint GetFBO() const { return fbo;}

        /**
         * @brief Gets the HDR texture associated with this framebuffer.
         * @return The OpenGL identifier of the HDR texture.
         */
        GLuint getHDRTexture() const { return hdrTexture; }

    private:
        /**
         * @brief Initializes the OpenGL resources for the framebuffer.
         *
         * Creates and configures the FBO, HDR texture, and renderbuffer.
         */
        void initialize();

        /**
         * @brief Cleans up the OpenGL resources associated with the framebuffer.
         */
        void cleanup();

        int m_width; /**< Current width of the framebuffer in pixels. */
        int m_height; /**< Current height of the framebuffer in pixels. */

        GLuint fbo; /**< OpenGL framebuffer object identifier. */
        GLuint hdrTexture; /**< OpenGL HDR texture identifier associated with the framebuffer. */
        GLuint rbo; /**< OpenGL renderbuffer identifier for depth buffer. */
    };

    /**
     * @class HDRsystem
     * @brief Complete system for HDR rendering with adaptive tonemapping.
     *
     * This class provides a comprehensive solution for rendering HDR content,
     * applying tonemapping (adaptive or manual) and adjusting visual parameters
     * such as exposure, contrast, and saturation.
     */
    class HDRsystem 
    {
    public:

        /**
         * @brief Constructor that initializes the HDR system with specified dimensions.
         * @param width Initial width of the viewport in pixels.
         * @param height Initial height of the viewport in pixels.
         */
        HDRsystem(int width, int height);

        /**
        * @brief Destructor that releases all resources of the HDR system.
        */
        ~HDRsystem();

        /**
         * @brief Macro that makes the class movable but not copyable.
         *
         * Implements move constructors and operators while disabling copy constructors and operators.
         */
        MOVABLE_BUT_NOT_COPYABLE(HDRsystem)

        /**
        * @brief Resizes the HDR system to accommodate a new viewport size.
        * @param width New width of the viewport in pixels.
        * @param height New height of the viewport in pixels.
        */
        void resize(int width, int height);

        /**
         * @brief Begins the HDR rendering process.
         *
         * Sets up the HDR framebuffer to receive the scene to be rendered.
         * Must be called before rendering the scene.
         */
        void beginRender();

        /**
        * @brief Finalizes the HDR rendering process and applies post-processing.
        * @param bTonneMapping Flag indicating whether tonemapping should be applied.
        * @param bAutoTonemapping Flag indicating whether the tonemapping should be adaptive.
        *
        * Applies tonemapping and other post-processing effects to the HDR content
        * and presents it to the default framebuffer.
        */
        void endRender(bool bTonneMapping, bool bAutoTonemapping);

        /**
         * @brief Gets the current exposure value.
         * @return The current exposure value.
         */
        float getExposure() const { return m_exposure; }
        /**
         * @brief Sets a new exposure value.
         * @param exposure New exposure value.
         */
        void setExposure(float exposure) { m_exposure = exposure; }

        /**
         * @brief Gets the current contrast value.
         * @return The current contrast value.
         */
        float getContrast() const { return m_contrast; }

        /**
         * @brief Sets a new contrast value.
         * @param contrast New contrast value.
         */
        void setContrast(float contrast) { m_contrast = contrast; }

        /**
         * @brief Gets the current saturation value.
         * @return The current saturation value.
         */
        float getSaturation() const { return m_saturation; }

        /**
         * @brief Sets a new saturation value.
         * @param saturation New saturation value.
         */
        void setSaturation(float saturation) { m_saturation = saturation; }

        /**
         * @brief Renders a quad for full-screen post-processing.
         *
         * Draws a quad covering the entire screen, used to apply post-processing
         * shaders to the HDR texture.
         */
        void renderQuad();

        /**
         * @brief Gets the HDR framebuffer associated with this system.
         * @return Pointer to the HDRFramebuffer object.
         */
        HDRFramebuffer* GetFrameBuffer() const {
            return m_hdrFramebuffer.get();
        }

        /**
        * @brief Sets the target middle gray value for adaptive tonemapping.
        * @param value New target middle gray value (typically between 0.18 and 0.5).
        *
        * This value determines what luminance level is mapped to middle gray in the final image,
        * significantly affecting the overall brightness of the image after tonemapping.
        */
        void setTargetMiddleGray(float value);

        /**
         * @brief Gets the current target middle gray value.
         * @return The current target middle gray value.
         */
        float getTargetMiddleGray() const;

        /**
         * @brief Sets the adaptation speed for adaptive tonemapping.
         * @param value New adaptation speed (typically between 0.01 and 1.0).
         *
         * Controls how quickly the system adapts to luminance changes in the scene.
         * Higher values produce faster adaptations but may cause flickering.
         */
        void setAdaptationSpeed(float value);

        /**
        * @brief Gets the current adaptation speed.
        * @return The current adaptation speed.
        */
        float getAdaptationSpeed() const;
    private:

        /**
         * @brief Initializes the internal components of the HDR system.
         *
         * Sets up the shaders, HDR framebuffer, quad geometry for post-processing,
         * and adaptive tonemapping components.
         */
        void initialize();

        std::unique_ptr<HDRFramebuffer> m_hdrFramebuffer; /**< HDR framebuffer for rendering the scene with high dynamic range. */
        ShaderProgram m_hdrPostprocessShader; /**< Shader program for HDR post-processing. */
        float m_exposure; /**< Exposure factor for global brightness adjustment. */
        float m_contrast; /**< Contrast factor for adjusting difference between light and dark areas. */
        float m_saturation; /**< Saturation factor for adjusting color intensity. */
        int m_width; /**< Current width of the viewport in pixels. */
        int m_height; /**< Current height of the viewport in pixels. */
        GLuint m_quadVAO; /**< Vertex Array Object identifier for the post-processing quad. */
        GLuint m_quadVBO; /**< Vertex Buffer Object identifier for the post-processing quad. */
        std::unique_ptr<SceneAnalyzer> m_sceneAnalyzer; /**< Scene analyzer that calculates luminance statistics for adaptive tonemapping. */
        std::unique_ptr<AdaptiveTonemapper> m_adaptiveTonemapper; /**< Adaptive tonemapper that automatically adjusts exposure based on content. */
    };

}


#endif