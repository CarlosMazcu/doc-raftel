// ===== DEWFERRED SHADING ===== //
//#version 460 core
//out vec4 FragColor;
//
//in vec2 TexCoords;
//
//layout(binding = 0) uniform sampler2D gPosition;
//layout(binding = 1) uniform sampler2D gNormal;
//layout(binding = 2) uniform sampler2D gAlbedoSpec;
//
//uniform mat4 lightSpaceMatrix;
//vec4 FragPosLightSpace; 
//
//uniform int cast_shadows;
//
//layout(binding = 10) uniform sampler2D shadowMap; 
//layout(binding = 10) uniform samplerCube pointShadowMap; 
//uniform float farPlane;
//
//uniform vec3 cam_pos;
//
//uniform int has_ambient_light;
//uniform vec3 ambient_color;
//
//struct Light {
//    int type;                // 0 = direccional, 1 = puntual, 2 = spot
//    vec3 color;              // Color de la luz
//    vec3 position;           // Posición (puntual/spot)
//    vec3 direction;          // Dirección (direccional/spot)
//    float intensity;         // Intensidad de la luz
//    float range;             // Rango máximo de la luz puntual/spot
//    float innerCone;         // Ángulo interno del spot
//    float outerCone;         // Ángulo externo del spot
//};
//
//uniform Light lights;
//
////tonne mapping uniforms
//uniform float contrast;
//uniform float exposure;
//uniform float saturation;
//
//
//vec3 gridSamplingDisk[20] = vec3[]
//(
//   vec3(1, 1,  1), vec3( 1, -1,  1), vec3(-1, -1,  1), vec3(-1, 1,  1), 
//   vec3(1, 1, -1), vec3( 1, -1, -1), vec3(-1, -1, -1), vec3(-1, 1, -1),
//   vec3(1, 1,  0), vec3( 1, -1,  0), vec3(-1, -1,  0), vec3(-1, 1,  0),
//   vec3(1, 0,  1), vec3(-1,  0,  1), vec3( 1,  0, -1), vec3(-1, 0, -1),
//   vec3(0, 1,  1), vec3( 0, -1,  1), vec3( 0, -1, -1), vec3( 0, 1, -1)
//);
//
////************** POINT LIGHTS **************//
//float PointShadowCalculation(vec3 fragPos, vec3 lightPos, samplerCube depthCubeMap) {
//    vec3 fragToLight = fragPos - lightPos;
//    float currentDepth = length(fragToLight);
//    
//    // Obtener la profundidad más cercana en la dirección del fragmento
//    float closestDepth = texture(depthCubeMap, fragToLight).r;
//    closestDepth *= farPlane; // Escalar la profundidad (porque en el cubemap está normalizada de 0 a 1)
//
//    // Bias dinámico para evitar shadow acne
//    float bias = 0.15;
//    float shadow = 0.0;
//    
//    // PCF con muestreo en varias direcciones
//    int samples = 20; // Número de muestras para suavizar
//    
//    float viewDistance = length(cam_pos - fragPos);
//    float diskRadius = (1.0 + (viewDistance / farPlane)) / 25.0;
//    for(int i = 0; i < samples; ++i)
//    {
//        float closestDepth = texture(depthCubeMap, fragToLight + gridSamplingDisk[i] * diskRadius).r;
//        closestDepth *= farPlane;   // undo mapping [0;1]
//        if(currentDepth - bias > closestDepth)
//            shadow += 1.0;
//    }
//    shadow /= float(samples);
//
//    return shadow;
//}
//
//vec3 CalculatePointLight(Light clight, vec3 fragPos, vec3 normal, vec3 albedo, float specular, vec3 viewDir){
//    float distance_ = length(clight.position - fragPos);
//    
//    vec3 lightDir = normalize(clight.position - fragPos);
//    vec3 diffuse = max(dot(normal, lightDir), 0.0) * albedo * clight.color;
//
//    vec3 halfwayDir = normalize(lightDir + viewDir);
//    float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);
//    vec3 newSpecular = clight.color * spec * specular;
//
//    float attenuation = max(0.0f, 1.0f - (distance_ * distance_) / (clight.range * clight.range));
//
//    diffuse *= attenuation;
//    newSpecular *= attenuation;
//
//    float shadow = 0.0;
//    
//    //if(cast_shadows == 1){shadow = PointShadowCalculation(fragPos, clight.position, pointShadowMap);}
//    shadow = PointShadowCalculation(fragPos, clight.position, pointShadowMap);
//
//    return (1.0 - shadow) * (diffuse + newSpecular);
//}
//
//
//float SpotShadowCalculation(vec4 fragPosLightSpace, vec3 inNormal, vec3 inFragPos) {
//    // perform perspective divide
//    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
//    // transform to [0,1] range
//    projCoords = projCoords * 0.5 + 0.5;
//    // get closest depth value from light's perspective (using [0,1] range fragPosLight as coords)
//    float closestDepth = texture(shadowMap, projCoords.xy).r;
//    // get depth of current fragment from light's perspective
//    float currentDepth = projCoords.z;
//    // calculate bias (based on depth map resolution and slope)
//    vec3 normal = normalize(inNormal);
//    vec3 lightDir = normalize(lights.position - inFragPos);
//    //vec3 lightDir = normalize(dirLight.direction);
//    float bias = max(0.05 * (1.0 - dot(normal, lightDir)), 0.005);
//    // check whether current frag pos is in shadow
//    // float shadow = currentDepth - bias > closestDepth  ? 1.0 : 0.0;
//    // PCF
//    float shadow = 0.0;
//    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
//    for(int x = -1; x <= 1; ++x) {
//        for(int y = -1; y <= 1; ++y) {
//            float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
//            shadow += currentDepth - bias > pcfDepth  ? 1.0 : 0.0;
//        }
//    }
//    shadow /= 9.0;
//
//    // keep the shadow at 0.0 when outside the far_plane region of the light's frustum.
//    if(projCoords.z > 1.0)
//    shadow = 0.0;
//
//    return shadow;
//}
//
//
// vec3 CalculateSpotLight(Light slight, vec3 fragPos, vec3 normal, vec3 albedo, float specular, vec3 viewDir) {
//
//    vec3 light_dir = normalize(slight.position - fragPos);
//    float distance = length(slight.position - fragPos);
//
//    float diff = max(dot(normal, light_dir), 0.0);
//    vec3 diffuse = diff * albedo * slight.color;
//
//    vec3 halfwayDir = normalize(light_dir + viewDir);
//    float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);
//    vec3 newSpecular = slight.color * spec * specular;
//
//    float attenuation = max(0.0, 1.0 - (distance * distance) / (slight.range * slight.range));
//
//    float theta = dot(light_dir, normalize(-slight.direction));
//    float epsilon = slight.innerCone - slight.outerCone;
//    float intensity = clamp((theta - slight.outerCone) / epsilon, 0.0, 1.0);
//
//    diffuse *= attenuation * intensity;
//    newSpecular *= attenuation * intensity;
//
//    float shadow = 0.0;
//
//    if(cast_shadows == 1){shadow = SpotShadowCalculation(FragPosLightSpace, normal, fragPos);}
//
//    return (1.0f - shadow) * (diffuse + newSpecular);
//} 
//
//float DirShadowCalculation(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir) {
//
//    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
//    projCoords = projCoords * 0.5 + 0.5;
//
//    // Obtener la profundidad almacenada en el shadow map
//    float closestDepth = texture(shadowMap, projCoords.xy).r;
//    float currentDepth = projCoords.z;
//
//    // Calcular bias basado en el ángulo entre la normal y la dirección de la luz
//    float bias = max(0.05 * (1.0 - dot(normal, lightDir)), 0.002);
//
//    // Suavizado con PCF (Percentage Closer Filtering)
//    float shadow = 0.0;
//    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
//    for (int x = -1; x <= 1; ++x) {
//        for (int y = -1; y <= 1; ++y) {
//            float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
//            shadow += (currentDepth - bias > pcfDepth) ? 1.0 : 0.0;
//        }
//    }
//    shadow /= 9.0;
//
//    // Evitar sombras fuera del rango del shadow map
//    if (projCoords.z > 1.0)
//        shadow = 0.0;
//
//    return shadow;
//}
//
//vec3 CalculateDirectionalLight(Light dlight, vec3 fragPos, vec3 normal, vec3 albedo, float specular, vec3 viewDir) {
//   vec3 lightDir = normalize(-dlight.direction);
//
//    float diff = max(dot(normal, lightDir), 0.0);
//    vec3 diffuse = diff * albedo;
//
//    vec3 halfwayDir = normalize(lightDir + viewDir);
//    float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);
//    vec3 newSpecular = dlight.color * spec * specular;
//
//    float shadow = 0.0;
//
//    //if(cast_shadows == 1){shadow = DirShadowCalculation(FragPosLightSpace, normal, lightDir);}
//
//    shadow = DirShadowCalculation(FragPosLightSpace, normal, lightDir);
//
//    return (1.0 - shadow) * (diffuse + newSpecular);
//}
//
//
//void main()
//{             
//    // retrieve data from gbuffer
//    vec3 FragPos = texture(gPosition, TexCoords).rgb;
//    vec3 Normal = texture(gNormal, TexCoords).rgb;
//    vec3 Diffuse = texture(gAlbedoSpec, TexCoords).rgb;
//    float Specular = texture(gAlbedoSpec, TexCoords).a;
//
//    FragPosLightSpace = lightSpaceMatrix * vec4(FragPos, 1);
//    
//    // then calculate lighting as usual
//    vec3 finalColor  = vec3(0);
//    vec3 viewDir  = normalize(cam_pos - FragPos);
//    float constant = 1.0f;
//
//    // Calcular luz
//    if (lights.type == 0) { // Direccional
//        finalColor += CalculateDirectionalLight(lights, FragPos, Normal, Diffuse, Specular, viewDir);
//    } else if (lights.type == 1) { // Puntual
//        finalColor += CalculatePointLight(lights, FragPos, Normal, Diffuse, Specular, viewDir);
//    } else if (lights.type == 2) { // Spot
//        finalColor += CalculateSpotLight(lights, FragPos, Normal, Diffuse, Specular, viewDir);
//    } 
//
//    FragColor = vec4(finalColor, 1.0);
//}
#version 460 core
out vec4 FragColor;

in vec2 TexCoords;

// G-Buffer textures
layout(binding = 0) uniform sampler2D gPosition;
layout(binding = 1) uniform sampler2D gNormal;
layout(binding = 2) uniform sampler2D gAlbedoSpec;
layout(binding = 3) uniform sampler2D gRoughMetal;  // Rugosidad (R), Metalicidad (G), SSS-Factor (B), Fresnel (A)

// Shadow maps
uniform mat4 lightSpaceMatrix;
layout(binding = 10) uniform sampler2D shadowMap; 
layout(binding = 10) uniform samplerCube pointShadowMap; 
uniform float farPlane;
uniform int cast_shadows;

uniform vec3 cam_pos;

uniform int has_ambient_light;
uniform vec3 ambient_color;


struct Light {
    int type;                // 0 = direccional, 1 = puntual, 2 = spot
    vec3 color;              // Color de la luz
    vec3 position;           // Posición (puntual/spot)
    vec3 direction;          // Dirección (direccional/spot)
    float intensity;         // Intensidad de la luz
    float range;             // Rango máximo de la luz puntual/spot
    float innerCone;         // Ángulo interno del spot
    float outerCone;         // Ángulo externo del spot
};

uniform Light lights;

// ---- Muestreo para PCF en shadow mapping ----
vec3 gridSamplingDisk[20] = vec3[]
(
   vec3(1, 1,  1), vec3( 1, -1,  1), vec3(-1, -1,  1), vec3(-1, 1,  1), 
   vec3(1, 1, -1), vec3( 1, -1, -1), vec3(-1, -1, -1), vec3(-1, 1, -1),
   vec3(1, 1,  0), vec3( 1, -1,  0), vec3(-1, -1,  0), vec3(-1, 1,  0),
   vec3(1, 0,  1), vec3(-1,  0,  1), vec3( 1,  0, -1), vec3(-1, 0, -1),
   vec3(0, 1,  1), vec3( 0, -1,  1), vec3( 0, -1, -1), vec3( 0, 1, -1)
);

// ---- Funciones GGX para PBR ----
float DistributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;

    float num = a2;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    denom = 3.14159265359 * denom * denom;

    return num / denom;
}

float GeometrySchlickGGX(float NdotV, float roughness) {
    float k = (roughness + 1.0);
    k = (k * k) / 8.0;

    float denom = NdotV * (1.0 - k) + k;
    return NdotV / denom;
}

float GeometrySmith(vec3 N, vec3 V, vec3 L, float roughness) {
    float NdotV = max(dot(N, V), 0.0);
    float NdotL = max(dot(N, L), 0.0);
    float ggx1 = GeometrySchlickGGX(NdotV, roughness);
    float ggx2 = GeometrySchlickGGX(NdotL, roughness);

    return ggx1 * ggx2;
}

vec3 FresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(1.0 - cosTheta, 5.0);
}

float CalculateFresnel(vec3 viewDir, vec3 normal, float fresnelFactor) {
    return pow(1.0 - max(dot(viewDir, normal), 0.0), fresnelFactor);
}

// ---- Funciones de cálculo de sombras ----
float DirShadowCalculation(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir) {
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;

    // Obtener la profundidad almacenada en el shadow map
    float closestDepth = texture(shadowMap, projCoords.xy).r;
    float currentDepth = projCoords.z;

    // Calcular bias basado en el ángulo entre la normal y la dirección de la luz
    float bias = max(0.05 * (1.0 - dot(normal, lightDir)), 0.002);

    // Suavizado con PCF (Percentage Closer Filtering)
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
    for (int x = -1; x <= 1; ++x) {
        for (int y = -1; y <= 1; ++y) {
            float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
            shadow += (currentDepth - bias > pcfDepth) ? 1.0 : 0.0;
        }
    }
    shadow /= 9.0;

    // Evitar sombras fuera del rango del shadow map
    if (projCoords.z > 1.0)
        shadow = 0.0;

    return shadow;
}

float PointShadowCalculation(vec3 fragPos, vec3 lightPos, samplerCube depthCubeMap) {
    vec3 fragToLight = fragPos - lightPos;
    float currentDepth = length(fragToLight); // Distancia desde el fragmento a la luz
    
    // Obtener la profundidad más cercana en la dirección del fragmento
    float closestDepth = texture(depthCubeMap, fragToLight).r;
    closestDepth *= farPlane; // Escalar la profundidad (porque en el cubemap está normalizada de 0 a 1)

    // Bias dinámico para evitar shadow acne
    float bias = 0.15;
    float shadow = 0.0;
    
    // PCF con muestreo en varias direcciones
    int samples = 20; // Número de muestras para suavizar
    
    float viewDistance = length(cam_pos - fragPos);
    float diskRadius = (1.0 + (viewDistance / farPlane)) / 25.0;
    for(int i = 0; i < samples; ++i)
    {
        float closestDepth = texture(depthCubeMap, fragToLight + gridSamplingDisk[i] * diskRadius).r;
        closestDepth *= farPlane;   // undo mapping [0;1]
        if(currentDepth - bias > closestDepth)
            shadow += 1.0;
    }
    shadow /= float(samples);

    return shadow;
}

float SpotShadowCalculation(vec4 fragPosLightSpace, vec3 inNormal, vec3 inFragPos) {
    // perform perspective divide
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    // transform to [0,1] range
    projCoords = projCoords * 0.5 + 0.5;
    // get closest depth value from light's perspective (using [0,1] range fragPosLight as coords)
    float closestDepth = texture(shadowMap, projCoords.xy).r;
    // get depth of current fragment from light's perspective
    float currentDepth = projCoords.z;
    // calculate bias (based on depth map resolution and slope)
    vec3 normal = normalize(inNormal);
    vec3 lightDir = normalize(lights.position - inFragPos);
    float bias = max(0.05 * (1.0 - dot(normal, lightDir)), 0.005);
    
    // PCF
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
    for(int x = -1; x <= 1; ++x) {
        for(int y = -1; y <= 1; ++y) {
            float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
            shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;
        }
    }
    shadow /= 9.0;

    // Evitar sombras fuera del rango del shadow map
    if(projCoords.z > 1.0)
        shadow = 0.0;

    return shadow;
}

// ---- Cálculos específicos de iluminación PBR ----
vec3 CalculateSpecularGGX(vec3 N, vec3 V, vec3 L, vec3 F0, float roughness) {
    vec3 H = normalize(V + L); // Half-vector

    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 0.0);
    float NdotH = max(dot(N, H), 0.0);
    float HdotV = max(dot(H, V), 0.0);

    // Componentes del modelo GGX
    float D = DistributionGGX(N, H, roughness);
    float G = GeometrySmith(N, V, L, roughness);
    vec3 F = FresnelSchlick(HdotV, F0);

    // Fórmula GGX
    vec3 specular = (D * G * F) / (4.0 * NdotV * NdotL + 0.001); // Evitar divisiones por cero
    
    return specular * NdotL;
}

// ---- Aplicar metalicidad ----
vec3 ApplyMetallic(vec3 diffuseColor, vec3 specularColor, float metallic) {
    return mix(diffuseColor, specularColor, metallic);
}

// ---- Subsurface Scattering ----
vec3 SubsurfaceScattering(vec3 lightColor, vec3 lightDir, vec3 viewDir, vec3 normal, float ssFactor) {
    // Producto escalar entre la normal y la dirección de la luz
    float NdotL = max(dot(normal, lightDir), 0.0);

    // Factor de dispersión: cuanto más disperso, menos dependemos de la dirección
    float scattering = pow(NdotL, 1.0 - ssFactor); // Controlar la dirección del scattering

    // Luz dispersada
    vec3 scatteredLight = lightColor * scattering * ssFactor;

    return scatteredLight;
}

// ---- Luz ambiental ----
vec3 CalculateAmbientLight(vec3 normal, vec3 viewDir, vec3 albedo, float metallic, float fresnelFactor) {
    // Componente difusa de la luz ambiental
    vec3 ambientDiffuse = ambient_color * albedo;

    // Componente especular Fresnel en la luz ambiental
    vec3 F0 = mix(vec3(0.04), albedo, metallic); // Mezcla de dieléctrico y metálico
    float NdotV = max(dot(normal, viewDir), 0.0);
    vec3 ambientSpecular = FresnelSchlick(NdotV, F0) * ambient_color;

    // Fresnel adicional
    float fresnel = CalculateFresnel(viewDir, normal, fresnelFactor);
    ambientSpecular *= fresnel;

    // Mezcla de componentes difusa y especular
    return ambientDiffuse + ambientSpecular;
}

// ---- Luz direccional ----
vec3 CalculateDirectionalLight(Light light, vec3 fragPos, vec3 normal, vec3 albedo, float roughness, float metallic, vec3 viewDir, float fresnelFactor, float ssFactor) {
    vec3 lightDir = normalize(-light.direction);

    // Componente difusa
    float diff = max(dot(normal, lightDir), 0.0);
    vec3 diffuse = diff * albedo;

    // Componente especular GGX
    vec3 F0 = mix(vec3(0.04), albedo, metallic); // Mezcla entre dieléctrico y metálico
    vec3 specular = CalculateSpecularGGX(normal, viewDir, lightDir, F0, roughness);

    // Fresnel adicional
    float fresnel = CalculateFresnel(viewDir, normal, fresnelFactor);
    specular *= fresnel;

    // Mezclar difuso y especular según el material
    vec3 finalColor = ApplyMetallic(diffuse, specular, metallic);

    // Calcular sombras
    float shadow = 0.0;
    if(cast_shadows == 1) {
        vec4 fragPosLightSpace = lightSpaceMatrix * vec4(fragPos, 1.0);
        shadow = DirShadowCalculation(fragPosLightSpace, normal, lightDir);
    }

    // Aplicar subsurface scattering
    vec3 sss = SubsurfaceScattering(light.color, lightDir, viewDir, normal, ssFactor);

    return (1.0 - shadow) * (finalColor * light.color * light.intensity) + sss * light.color;
}

// ---- Luz puntual ----
vec3 CalculatePointLight(Light light, vec3 fragPos, vec3 normal, vec3 albedo, float roughness, float metallic, vec3 viewDir, float fresnelFactor, float ssFactor) {
    vec3 lightDir = normalize(light.position - fragPos);

    // Componente difusa
    float diff = max(dot(normal, lightDir), 0.0);
    vec3 diffuse = diff * albedo;

    // Atenuación
    float distance = length(light.position - fragPos);
    float att = max(1.0 - (distance / light.range), 0.0);
    att = att * att; // Atenuación cuadrática

    // Componente especular GGX
    vec3 F0 = mix(vec3(0.04), albedo, metallic); // Mezcla entre dieléctrico y metálico
    vec3 specular = CalculateSpecularGGX(normal, viewDir, lightDir, F0, roughness);

    // Fresnel adicional
    float fresnel = CalculateFresnel(viewDir, normal, fresnelFactor);
    specular *= fresnel;

    // Mezclar difuso y especular según el material
    vec3 finalColor = ApplyMetallic(diffuse, specular, metallic);

    // Calcular sombras
    float shadow = 0.0;
    if(cast_shadows == 1) {
        shadow = PointShadowCalculation(fragPos, light.position, pointShadowMap);
    }

    // Aplicar subsurface scattering
    vec3 sss = SubsurfaceScattering(light.color, lightDir, viewDir, normal, ssFactor);

    return (1.0 - shadow) * (finalColor * att * light.color * light.intensity) + sss * att * light.color;
}

// ---- Luz spot ----
vec3 CalculateSpotLight(Light light, vec3 fragPos, vec3 normal, vec3 albedo, float roughness, float metallic, vec3 viewDir, float fresnelFactor, float ssFactor) {
    vec3 lightDir = normalize(light.position - fragPos);

    // Componente difusa
    float diff = max(dot(normal, lightDir), 0.0);
    vec3 diffuse = diff * albedo;

    // Atenuación
    float distance = length(light.position - fragPos);
    float att = max(1.0 - (distance / light.range), 0.0);
    att = att * att; // Atenuación cuadrática

    // Intensidad del spot
    float theta = dot(lightDir, normalize(-light.direction));
    float epsilon = light.innerCone - light.outerCone;
    float spotEffect = clamp((theta - light.outerCone) / epsilon, 0.0, 1.0);

    // Componente especular GGX
    vec3 F0 = mix(vec3(0.04), albedo, metallic); // Mezcla entre dieléctrico y metálico
    vec3 specular = CalculateSpecularGGX(normal, viewDir, lightDir, F0, roughness);

    // Fresnel adicional
    float fresnel = CalculateFresnel(viewDir, normal, fresnelFactor);
    specular *= fresnel;

    // Mezclar difuso y especular según el material
    vec3 finalColor = ApplyMetallic(diffuse, specular, metallic);

    // Calcular sombras
    float shadow = 0.0;
    if(cast_shadows == 1) {
        vec4 fragPosLightSpace = lightSpaceMatrix * vec4(fragPos, 1.0);
        shadow = SpotShadowCalculation(fragPosLightSpace, normal, fragPos);
    }

    // Aplicar subsurface scattering
    vec3 sss = SubsurfaceScattering(light.color, lightDir, viewDir, normal, ssFactor);

    return (1.0 - shadow) * (finalColor * att * spotEffect * light.color * light.intensity) + sss * att * spotEffect * light.color;
}

// La función de tone mapping se eliminó ya que se implementará con HDR más adelante

void main() {
    // Recuperar datos del G-Buffer
    vec3 FragPos = texture(gPosition, TexCoords).rgb;
    vec3 Normal = normalize(texture(gNormal, TexCoords).rgb);
    vec3 Albedo = texture(gAlbedoSpec, TexCoords).rgb;
    float Specular = texture(gAlbedoSpec, TexCoords).a;
    
    // Extraer rugosidad, metalicidad, SSS-Factor y Fresnel del G-Buffer
    vec4 RoughMetalInfo = texture(gRoughMetal, TexCoords);
    float Roughness = RoughMetalInfo.r;
    float Metallic = RoughMetalInfo.g;
    float SSSFactor = RoughMetalInfo.b;  
    float FresnelFactor = RoughMetalInfo.a;  

    vec3 viewDir = normalize(cam_pos - FragPos);
    vec3 finalColor = vec3(0.0);
    
    // Luz ambiental
    if (has_ambient_light != 0) {
        finalColor += CalculateAmbientLight(Normal, viewDir, Albedo, Metallic, FresnelFactor);
    }
    
    // Calcular contribución de luz según el tipo
    if (lights.type == 0) { // Direccional
        finalColor += CalculateDirectionalLight(lights, FragPos, Normal, Albedo, Roughness, Metallic, viewDir, FresnelFactor, SSSFactor);
    } else if (lights.type == 1) { // Puntual
        finalColor += CalculatePointLight(lights, FragPos, Normal, Albedo, Roughness, Metallic, viewDir, FresnelFactor, SSSFactor);
    } else if (lights.type == 2) { // Spot
        finalColor += CalculateSpotLight(lights, FragPos, Normal, Albedo, Roughness, Metallic, viewDir, FresnelFactor, SSSFactor);
    }
    
    FragColor = vec4(finalColor, 1.0);
}