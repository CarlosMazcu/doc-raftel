#ifndef __LINERENDERER_H__
#define __LINERENDERER_H__ 1

#include "glm/glm.hpp"
#include <raftel/global_macros.hpp>
#include <vector>
#include <memory>

namespace Raftel {
    class ShaderProgram;

    /**
    * @struct LineData
    * @brief Structure representing a vertex for line rendering with position and color.
    *
    * This structure holds the necessary data for rendering a single vertex of a line,
    * including its position in 3D space and its color with RGBA components.
    */
    struct LineData {
        glm::vec3 pos;   /**< Position of the vertex in 3D space. */
        glm::vec4 color; /**< Color of the vertex in RGBA format. */
    };

    /**
     * @brief Maximum number of lines that can be rendered in a single batch.
     *
     * Defines the storage size for the line buffer. Each line consists of two vertices,
     * so the actual number of vertices that can be stored is twice this value.
     */
    const uint32_t MAX_LINES(1024 * 1024);

    /**
    * @class LineRenderer
    * @brief Utility class for rendering lines and wireframe shapes in 3D space.
    *
    * LineRenderer provides a simple interface for drawing debug lines, wireframe boxes,
    * and other primitive shapes useful for visualization and debugging purposes.
    * It uses a shader storage buffer object (SSBO) for efficient batched rendering.
    */
    class LineRenderer {
    public:
        /**
         * @brief Constructor that initializes the line renderer.
         *
         * Creates the GPU buffer for line data and loads the line rendering shaders.
         */
        LineRenderer();

        /**
         * @brief Destructor that cleans up GPU resources.
         *
         * Releases the GPU buffer allocated for line data.
         */
        ~LineRenderer();

        /**
        * @brief Macro that makes the class neither copyable nor movable.
        *
        * Disables both copy and move constructors and assignment operators.
        */
        NO_COPYABLE_OR_MOVABLE(LineRenderer);

        /**
        * @brief Collection of line vertices awaiting rendering.
        *
        * This vector accumulates the line vertices until Flush() is called to render them.
        * Each line requires two consecutive vertices in this vector.
        */
        std::vector<LineData> lines;

        /**
         * @brief Adds a line segment between two points to the render queue.
         * @param p1 Start point of the line in world space.
         * @param p2 End point of the line in world space.
         * @param color Color of the line in RGBA format.
         *
         * Adds two vertices to the lines vector, representing the start and end points of a line segment.
         * Both vertices will have the same color.
         */
        void Line(const glm::vec3& p1, const glm::vec3& p2, const glm::vec4& color);

        /**
         * @brief Adds a wireframe box with specified size to the render queue.
         * @param model Model matrix defining the position, orientation, and scale of the box.
         * @param size Half-extents of the box in each dimension.
         * @param color Color of the box wireframe in RGBA format.
         *
         * Generates 12 lines forming the edges of a box with dimensions (-size, size) in local space,
         * transformed by the given model matrix to position it in world space.
         */
        void Box(const glm::mat4& model, const glm::vec3& size, const glm::vec4& color);

        /**
         * @brief Adds a wireframe box defined by min/max vertices to the render queue.
         * @param model Model matrix defining additional transformation for the box.
         * @param minVert Minimum vertex of the box (smallest x, y, z coordinates).
         * @param maxVert Maximum vertex of the box (largest x, y, z coordinates).
         * @param color Color of the box wireframe in RGBA format.
         *
         * Generates 12 lines forming the edges of a box defined by its minimum and maximum vertices,
         * transformed by the given model matrix to position it in world space.
         */
        void Box(const glm::mat4& model, const glm::vec3& minVert, const glm::vec3& maxVert, const glm::vec4& color);

        /**
         * @brief Renders all queued lines and clears the queue.
         * @param view The camera view matrix.
         * @param projection The camera projection matrix.
         *
         * Uploads all queued line data to the GPU, binds the line shader and buffer,
         * renders all lines in a single draw call, and finally clears the queue.
         * This method should be called once per frame, after all lines have been added.
         */
        void Flush(const glm::mat4& view, const glm::mat4& projection);

        /**
         * @brief OpenGL buffer handle for the line data.
         *
         * This buffer is a Shader Storage Buffer Object (SSBO) that holds the vertex
         * data for all lines to be rendered.
         */
        uint32_t buffer;

        /**
         * @brief Shader program used for rendering lines.
         *
         * This shader program is loaded from "lines.vs" and "lines.fs" files and
         * is responsible for rendering the lines with the appropriate transformations.
         */
        std::unique_ptr<ShaderProgram> shader;

    };
   
} // namespace Raftel

#endif 